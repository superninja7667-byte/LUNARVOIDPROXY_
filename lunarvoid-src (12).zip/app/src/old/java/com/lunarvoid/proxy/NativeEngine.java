package com.lunarvoid.proxy;

/** The old engine (liblunarvoid50.so), unchanged. */
final class NativeEngine {
    private NativeEngine() {
    }

    static String call(String json) {
        return GameEngine50.callNative(json);
    }

    static boolean configure(String sessionFile, String sessionKey) {
        return GameEngine50.configureNative(sessionFile, sessionKey);
    }
}
