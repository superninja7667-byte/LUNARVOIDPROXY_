#!/usr/bin/env bash
# APK NEXT: the rebuilt engine (new forms menu, server resource packs passed on).
# On failure, the end of the error log is written to the run's Summary page.
set -u
export PATH="$PATH:$(go env GOPATH)/bin"
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
SUM="$GITHUB_STEP_SUMMARY"

fail() { # $1 = title, $2 = log file
  { echo "## APK NEXT FAILED: $1"; echo; echo "Send me a screenshot of this box."; echo; echo '```'; tail -n 45 "$2"; echo '```'; } >> "$SUM"
  exit 1
}

cd "$GITHUB_WORKSPACE/src/engine"
LOG="$GITHUB_WORKSPACE/go-build.log"
{
  go mod tidy &&
  go install golang.org/x/mobile/cmd/gomobile@latest &&
  go get golang.org/x/mobile/bind &&
  gomobile init &&
  mkdir -p ../app/libs &&
  gomobile bind -target=android/arm64 -androidapi 26 -ldflags="-s -w" -o ../app/libs/engine.aar .
} > "$LOG" 2>&1 || fail "the Go engine did not compile" "$LOG"

cd "$GITHUB_WORKSPACE/src"
GLOG="$GITHUB_WORKSPACE/gradle-next.log"
gradle :app:assembleNextDebug --no-daemon > "$GLOG" 2>&1 || fail "the Android part did not build" "$GLOG"
echo "### APK NEXT built: install the file named app-next-debug.apk (app name: LUNARVOID NEXT)" >> "$SUM"
