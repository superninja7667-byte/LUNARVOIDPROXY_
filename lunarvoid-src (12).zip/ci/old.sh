#!/usr/bin/env bash
# APK OLD: the old engine in the new Android code.
set -e
cd "$GITHUB_WORKSPACE/src"
gradle :app:assembleOldDebug --no-daemon
echo "### APK OLD built: install the file named app-old-debug.apk" >> "$GITHUB_STEP_SUMMARY"
