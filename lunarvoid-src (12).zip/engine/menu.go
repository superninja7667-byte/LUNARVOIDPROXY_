package engine

import (
	"encoding/json"
	"fmt"
	"strings"
)

// The in-game menu is made of normal Minecraft forms: a menu form with one
// button per category, then a form with one switch per module. It does not
// replace any of the game's own screens, so it cannot clash with the server's
// resource packs or with other menus.

// Categories, in the order they appear.
var menuTabs = []string{"HUD", "Combat", "Movement", "Visuals", "World", "Client"}

type card struct {
	name, desc, kind, arg string // kind: mod, emote, info
}

func modulesFor(tab string) []card {
	if tab == "Client" {
		return []card{
			{"Emote menu", "Open this menu by playing an emote.", "emote", ""},
			{"Skins & packs", "Manage them in the LUNARVOID app (Player tab).", "info", "skins"},
			{"Help", "/.menu opens this menu. /.help shows tips.", "info", "help"},
		}
	}
	var out []card
	for _, name := range catalog[tab] {
		d := catalogDesc[name]
		if d == "" {
			d = "Preview only."
		}
		out = append(out, card{name, d, "mod", name})
	}
	return out
}

func tabNote(tab string) string {
	switch tab {
	case "Client":
		return "Menu and app shortcuts."
	case "World":
		return "No modules here yet."
	}
	return "Preview only: these switches are saved but do nothing yet."
}

func isOn(c card, st settings) bool {
	switch c.kind {
	case "emote":
		return st.EmoteMenu
	case "mod":
		return st.Mods[c.arg]
	}
	return false
}

// mainMenuForm is the first screen: one button per category.
func mainMenuForm(st settings) []byte {
	buttons := make([]map[string]string, 0, len(menuTabs))
	for _, t := range menuTabs {
		mods := modulesFor(t)
		on := 0
		for _, c := range mods {
			if isOn(c, st) {
				on++
			}
		}
		line2 := fmt.Sprintf("§8%d modules  ·  %d on", len(mods), on)
		if len(mods) == 0 {
			line2 = "§8Nothing here yet"
		}
		buttons = append(buttons, map[string]string{"text": "§l§b" + t + "§r\n" + line2})
	}
	body, _ := json.Marshal(map[string]any{
		"type":    "form",
		"title":   "§l§bLUNAR§3VOID",
		"content": "§7Pick a category. Switches are previews for now and do nothing yet.",
		"buttons": buttons,
	})
	return body
}

// tabForm is the second screen: a switch for every module in the category.
// The first element is a label, so the answer for card i is at position i+1.
func tabForm(tab string, st settings) (body []byte, cards []card) {
	cards = modulesFor(tab)
	elements := []map[string]any{{"type": "label", "text": "§7" + tabNote(tab) + "\n§8Close this screen to go back."}}
	for _, c := range cards {
		if c.kind == "info" {
			elements = append(elements, map[string]any{"type": "label", "text": "§f" + c.name + " §8— " + shorten(c.desc, 70)})
			continue
		}
		elements = append(elements, map[string]any{
			"type":    "toggle",
			"text":    "§f" + c.name + " §8— " + shorten(c.desc, 46),
			"default": isOn(c, st),
		})
	}
	body, _ = json.Marshal(map[string]any{
		"type":    "custom_form",
		"title":   "§l§b" + tab,
		"content": elements,
	})
	return body, cards
}

func shorten(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return strings.TrimSpace(string(r[:n-1])) + "…"
}
