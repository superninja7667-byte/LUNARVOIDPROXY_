package engine

import (
	"context"
	"encoding/json"
	"net"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/sandertv/gophertunnel/minecraft"
	"github.com/sandertv/gophertunnel/minecraft/auth"
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"github.com/sandertv/gophertunnel/minecraft/resource"
	"golang.org/x/oauth2"
)

const formID uint32 = 0x4C560001 // our menu form; real server forms use small ids

type runner struct {
	listener *minecraft.Listener
	status   *minecraft.ForeignStatusProvider
	mu       sync.Mutex
	conns    map[*minecraft.Conn]struct{}
}

func (r *runner) add(c *minecraft.Conn) {
	r.mu.Lock()
	r.conns[c] = struct{}{}
	r.mu.Unlock()
}

func (r *runner) remove(c *minecraft.Conn) {
	r.mu.Lock()
	delete(r.conns, c)
	r.mu.Unlock()
}

func (r *runner) count() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.conns)
}

func (r *runner) close() {
	_ = r.listener.Close()
	closeStatus(r.status)
	r.mu.Lock()
	for c := range r.conns {
		_ = c.Close()
	}
	r.mu.Unlock()
}

func (s *engineState) fail(gen int, msg string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.gen == gen {
		s.state, s.errText, s.note = "error", msg, ""
	}
}

func (s *engineState) start(host string, port int, lan bool) {
	host = strings.TrimSpace(host)
	s.mu.Lock()
	switch {
	case s.state == "starting" || s.state == "running":
		s.mu.Unlock()
		return
	case s.tokenSource == nil:
		s.state, s.errText = "error", "Sign in with your Microsoft account first."
		s.mu.Unlock()
		return
	case host == "" || port <= 0 || port > 65535:
		s.state, s.errText = "error", "Enter a server address and port."
		s.mu.Unlock()
		return
	}
	s.gen++
	gen := s.gen
	src := s.tokenSource
	s.runLan = lan
	s.state, s.errText, s.note = "starting", "", ""
	s.mu.Unlock()
	go s.runProxy(gen, host, port, src)
}

func (s *engineState) stop() {
	s.mu.Lock()
	s.gen++
	r := s.run
	s.run = nil
	s.state, s.errText, s.note = "stopped", "", ""
	s.mu.Unlock()
	if r != nil {
		r.close()
	}
}

// fetchServerPacks connects to the real server once and keeps the resource
// packs it sends. Minecraft needs those packs to draw the server's blocks, so
// the proxy has to pass them on. Downloaded packs are saved on the phone, so
// only the first connection is slow.
func (s *engineState) fetchServerPacks(gen int, remote string, src oauth2.TokenSource, cache *auth.XBLTokenCache, packCache minecraft.DirResourcePackCache) ([]*resource.Pack, error) {
	ctx, cancel := context.WithTimeout(auth.WithXBLTokenCache(context.Background(), cache), 8*time.Minute)
	defer cancel()
	go func() { // stop waiting if you press Stop
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				if !s.current(gen) {
					cancel()
					return
				}
			}
		}
	}()
	conn, err := dialWithSmallPackets(ctx, minecraft.Dialer{TokenSource: src, ResourcePackCache: packCache}, remote)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	packs := conn.ResourcePacks()
	out := make([]*resource.Pack, len(packs))
	copy(out, packs)
	return out, nil
}

func (s *engineState) runProxy(gen int, host string, port int, src oauth2.TokenSource) {
	defer func() {
		if rec := recover(); rec != nil {
			s.fail(gen, "Internal error: "+panicText(rec))
		}
	}()
	remote := net.JoinHostPort(host, strconv.Itoa(port))

	tok, err := src.Token()
	if err != nil {
		s.fail(gen, "Sign-in expired. Please sign in again.")
		return
	}
	s.mu.Lock()
	s.writeToken(tok)
	dir := s.dir
	listenPort := s.listenPort
	lan := s.runLan
	userPacks := s.packPathsLocked()
	cache := s.xblCache
	if cache == nil {
		cache = xblConfig.NewTokenCache()
		s.xblCache = cache
	}
	s.mu.Unlock()

	packCache := minecraft.DirResourcePackCache{Dir: filepath.Join(dir, "packcache")}

	// Step 1: get the server's own resource packs so Minecraft can draw its blocks.
	s.setNote(gen, "Downloading the server's resources. The first time can take a few minutes.")
	serverPacks, perr := s.fetchServerPacks(gen, remote, src, cache, packCache)
	if !s.current(gen) {
		return
	}
	note := ""
	if perr != nil {
		note = "Could not download the server's resource pack, so some blocks may look invisible: " + perr.Error()
	}
	s.setNote(gen, note)

	// Step 2: open the proxy. Minecraft gets the server's packs, then your own packs.
	packs := append([]*resource.Pack{}, serverPacks...)
	for _, path := range userPacks {
		if extra, err := resource.ReadPath(path); err == nil {
			packs = append(packs, extra)
		}
	}
	cfg := minecraft.ListenConfig{
		ResourcePacks:        packs,
		TexturePacksRequired: len(serverPacks) > 0,
	}
	var fsp *minecraft.ForeignStatusProvider
	if p, err := minecraft.NewForeignStatusProvider(remote); err == nil {
		cfg.StatusProvider = p
		fsp = p
	}
	// Only this phone can join unless "same Wi-Fi" mode is on.
	bind := "127.0.0.1:" + strconv.Itoa(listenPort)
	if lan {
		bind = ":" + strconv.Itoa(listenPort)
	}
	l, err := cfg.Listen("raknet", bind)
	if err != nil {
		closeStatus(fsp)
		s.fail(gen, "Could not open port "+strconv.Itoa(listenPort)+": "+err.Error())
		return
	}

	r := &runner{listener: l, status: fsp, conns: map[*minecraft.Conn]struct{}{}}
	s.mu.Lock()
	if s.gen != gen {
		s.mu.Unlock()
		_ = l.Close()
		closeStatus(fsp)
		return
	}
	s.run = r
	s.state = "running"
	s.mu.Unlock()

	for {
		c, err := l.Accept()
		if err != nil {
			break
		}
		go s.handle(r, c.(*minecraft.Conn), remote, src, cache, packCache)
	}

	s.mu.Lock()
	if s.gen == gen && s.state == "running" {
		s.state, s.run = "stopped", nil
	}
	s.mu.Unlock()
}

// session is one Minecraft client connected through the proxy.
type session struct {
	s        *engineState
	client   *minecraft.Conn
	server   *minecraft.Conn
	mu       sync.Mutex
	form     openForm
	ourOpen  bool // our menu is on screen
	srvForms int  // server menus currently on screen
	queued   []*packet.ModalFormRequest
}

type openForm struct {
	kind  string // "main" or "tab"
	tab   string
	cards []card
}

func (s *engineState) handle(r *runner, conn *minecraft.Conn, remote string, src oauth2.TokenSource, cache *auth.XBLTokenCache, packCache minecraft.DirResourcePackCache) {
	r.add(conn)
	defer r.remove(conn)
	defer func() {
		if rec := recover(); rec != nil {
			msg := panicText(rec)
			s.noteError("Internal error: " + msg)
			_ = r.listener.Disconnect(conn, "LUNARVOID internal error: "+msg)
		}
	}()

	clientData := conn.ClientData()
	if path, slim, ok := s.skinPath(); ok {
		clientData = applySkin(clientData, path, slim)
	}
	// The shared token cache reuses the Xbox device token, and the pack cache
	// reuses packs already downloaded, so joining again is quick.
	ctx, cancel := context.WithTimeout(auth.WithXBLTokenCache(connContext(conn), cache), 3*time.Minute)
	server, err := dialWithSmallPackets(ctx, minecraft.Dialer{
		TokenSource:       src,
		ClientData:        clientData,
		ResourcePackCache: packCache,
	}, remote)
	cancel()
	if err != nil {
		_ = r.listener.Disconnect(conn, "LUNARVOID could not reach the server: "+err.Error())
		return
	}
	s.setAccountName(conn.IdentityData().DisplayName)

	sess := &session{s: s, client: conn, server: server}

	var wg sync.WaitGroup
	var startErr, spawnErr error
	wg.Add(2)
	go func() {
		defer wg.Done()
		startErr = conn.StartGame(server.GameData())
	}()
	go func() {
		defer wg.Done()
		spawnErr = server.DoSpawn()
	}()
	wg.Wait()
	if startErr != nil || spawnErr != nil {
		_ = server.Close()
		_ = r.listener.Disconnect(conn, "LUNARVOID could not start the game session.")
		return
	}

	var once sync.Once
	end := func(msg string) {
		once.Do(func() {
			_ = server.Close()
			_ = r.listener.Disconnect(conn, msg)
		})
	}

	go func() {
		defer func() {
			if rec := recover(); rec != nil {
				end("LUNARVOID internal error: " + panicText(rec))
			}
		}()
		for {
			pk, err := server.ReadPacket()
			if err != nil {
				end(err.Error())
				return
			}
			// Only one menu at a time: a server menu that arrives while ours is
			// open waits until ours is closed.
			if mf, ok := pk.(*packet.ModalFormRequest); ok && sess.holdServerForm(mf) {
				continue
			}
			if err := conn.WritePacket(pk); err != nil {
				end("connection lost")
				return
			}
		}
	}()

	for {
		pk, err := conn.ReadPacket()
		if err != nil {
			end("connection lost")
			return
		}
		if sess.fromClient(pk) {
			continue
		}
		if err := server.WritePacket(pk); err != nil {
			end("connection lost")
			return
		}
	}
}

// holdServerForm queues a server menu while ours is open. It returns true when
// the packet was queued and must not be sent yet.
func (c *session) holdServerForm(mf *packet.ModalFormRequest) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.ourOpen {
		c.queued = append(c.queued, mf)
		return true
	}
	c.srvForms++
	return false
}

// release closes our menu and lets any waiting server menus through.
func (c *session) release() {
	c.mu.Lock()
	c.ourOpen = false
	q := c.queued
	c.queued = nil
	c.srvForms += len(q)
	c.mu.Unlock()
	for _, f := range q {
		_ = c.client.WritePacket(f)
	}
}

// fromClient looks at packets the player sends. It returns true when the
// packet was ours and must not be forwarded to the server.
func (c *session) fromClient(pk packet.Packet) bool {
	switch p := pk.(type) {
	case *packet.CommandRequest:
		line := strings.TrimSpace(p.CommandLine)
		if strings.HasPrefix(line, "/.") {
			c.command(strings.ToLower(strings.TrimSpace(line[2:])))
			return true
		}
	case *packet.ModalFormResponse:
		if p.FormID == formID {
			c.formResponse(p)
			return true
		}
		c.mu.Lock()
		if c.srvForms > 0 {
			c.srvForms--
		}
		c.mu.Unlock()
	case *packet.Emote:
		if c.s.snapshot().EmoteMenu {
			c.openMain()
		}
	}
	return false
}

func (c *session) say(msg string) {
	_ = c.client.WritePacket(&packet.Text{TextType: packet.TextTypeRaw, Message: "§b[LUNARVOID]§r " + msg})
}

func (c *session) command(name string) {
	switch name {
	case "menu", "":
		c.openMain()
	case "help":
		c.say("/.menu opens the menu. Playing an emote opens it too.")
	case "replay":
		c.say("Replay is coming in the next build.")
	default:
		c.say("Unknown command. Try /.menu or /.help")
	}
}

func (c *session) openMain() {
	c.mu.Lock()
	if c.srvForms > 0 {
		c.mu.Unlock()
		c.say("Close the server's menu first, then open this one again.")
		return
	}
	c.ourOpen = true
	c.form = openForm{kind: "main"}
	c.mu.Unlock()
	_ = c.client.WritePacket(&packet.ModalFormRequest{FormID: formID, FormData: mainMenuForm(c.s.snapshot())})
}

func (c *session) openTab(tab string) {
	data, cards := tabForm(tab, c.s.snapshot())
	c.mu.Lock()
	c.ourOpen = true
	c.form = openForm{kind: "tab", tab: tab, cards: cards}
	c.mu.Unlock()
	_ = c.client.WritePacket(&packet.ModalFormRequest{FormID: formID, FormData: data})
}

func (c *session) formResponse(p *packet.ModalFormResponse) {
	raw := formData(p)
	c.mu.Lock()
	f := c.form
	c.mu.Unlock()

	if len(raw) == 0 || string(raw) == "null" { // the screen was closed
		if f.kind == "tab" {
			c.openMain() // closing a category goes back to the list
			return
		}
		c.release()
		return
	}
	switch f.kind {
	case "main":
		var idx int
		if json.Unmarshal(raw, &idx) == nil && idx >= 0 && idx < len(menuTabs) {
			c.openTab(menuTabs[idx])
			return
		}
		c.release()
	case "tab":
		var vals []any
		if json.Unmarshal(raw, &vals) == nil {
			changes := map[string]bool{}
			for i, cd := range f.cards {
				if 1+i >= len(vals) {
					break
				}
				b, ok := vals[1+i].(bool)
				if !ok {
					continue
				}
				switch cd.kind {
				case "mod":
					changes[cd.arg] = b
				case "emote":
					changes["emote"] = b
				}
			}
			c.s.applyToggles(changes)
		}
		c.openMain()
	default:
		c.release()
	}
}

// formData reads the raw answer of a form. It works whether the library stores
// the answer as a plain byte slice or as an optional value.
func formData(p *packet.ModalFormResponse) []byte {
	v := reflect.ValueOf(p).Elem().FieldByName("ResponseData")
	if !v.IsValid() {
		return nil
	}
	var data []byte
	if v.Kind() == reflect.Slice {
		data, _ = v.Interface().([]byte)
	} else if m := v.MethodByName("Value"); m.IsValid() {
		out := m.Call(nil)
		if len(out) == 2 && out[1].Kind() == reflect.Bool && out[1].Bool() {
			data, _ = out[0].Interface().([]byte)
		}
	}
	return data
}
