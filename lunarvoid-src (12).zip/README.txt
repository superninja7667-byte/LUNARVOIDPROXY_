LUNARVOID PROXY - source (build 8)

app/                       Android app (shared code) + app screen (assets/index.html = your v4 page)
  src/old/                 APK OLD  (app-old-debug.apk): your old engine, unchanged. Joins servers. OLD menu.
  src/next/                APK NEXT (app-next-debug.apk): the rebuilt engine. NEW forms menu.
  lunarvoid.jks            fixed signing key. Keep your repository PRIVATE.
engine/                    rebuilt Go engine (forms menu, passes the server's resource packs on)
ci/                        build scripts. Errors are written to the run's Summary page.
