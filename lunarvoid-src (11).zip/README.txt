LUNARVOID PROXY - source (build 7)

app/                       Android app (shared code) + app screen (assets/index.html = your v4 page)
  src/old/                 APK OLD: your old engine (liblunarvoid50.so), unchanged. Joins servers.
  src/next/                APK NEXT: the rebuilt engine below
  lunarvoid.jks            fixed signing key. Keep your repository PRIVATE.
engine/                    rebuilt Go engine
                           - in-game menu = normal Minecraft forms (no custom screens, nothing to clash with)
                           - passes the server's resource packs on to Minecraft
.github/workflows/build.yml  (already in your repo from last time)
